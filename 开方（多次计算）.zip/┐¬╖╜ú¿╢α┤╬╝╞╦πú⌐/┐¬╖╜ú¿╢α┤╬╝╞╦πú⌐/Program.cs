﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 开方_多次计算_
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                try
                {
                    Console.WriteLine("Please type a number");
                    string a = Console.ReadLine();
                    int aa = Convert.ToInt32(a);
                    if (aa <= 0)
                    {
                        Console.WriteLine("请输入大于零的数！");
                        Console.ReadKey();
                    }
                    else
                    {
                        double b = 0;
                        double bb = 0;
                        bool c;
                        do
                        {
                            b = b + 0.001;
                            bb = b * b;
                            c = (bb < aa);

                        }
                        while (c);
                        b = b - 0.001;
                        Console.WriteLine("根号下{0},约为{1:0.000}", a, b);
                        Console.ReadKey();
                    }
                }
                catch
                {
                    Console.WriteLine("请输入整数！");
                    Console.ReadKey();
                }
            }
        }
    }
}
