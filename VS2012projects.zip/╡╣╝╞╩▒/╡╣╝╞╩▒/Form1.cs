﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 倒计时
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buStart_Click(object sender, EventArgs e)
        {
            try
            {
                timer1.Enabled = true;
                int Second = Convert.ToInt32(textBox1.Text) * 60;
                labelSecond.Text = Second.ToString();
                progressBar1.Maximum = Second;
                progressBar1.Value = Second;
            }
            catch { }
        }

        private void labelSecond_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                int second = Convert.ToInt32(labelSecond.Text);
                second = second - 1;
                labelSecond.Text = second.ToString();
                progressBar1.Value--;
                if (second <= 0)
                {
                    progressBar1.Value = 0;
                    labelSecond.Text = "0";
                    timer1.Enabled = false;
                    MessageBox.Show("计时结束");
                }
            }
            catch { }
        }
    }
}
