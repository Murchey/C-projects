﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Key
{
    public class taw
    {
        public void ShowTAW()
        {
            //string time = "2022-12-27 20:54:01";
            //string writer = "Murchey";
            //Console.WriteLine(time);
            //Console.WriteLine(writer);
            Console.Title = "Call of Duty:Modern War II---(杜迪的来电：摩登战役2)";
            Console.ReadKey();
        }
    }
}
