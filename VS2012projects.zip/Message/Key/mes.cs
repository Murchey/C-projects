﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Key
{
    public class mes
    {
        
        public void ShowMes()
        {
            Console.ForegroundColor=ConsoleColor.Green;
            Console.WriteLine(" “别说俄语” ");
            Console.WriteLine("第三天 08:40:52");
            Console.WriteLine("上等兵 约瑟夫·艾伦  卧底姓名：阿列克谢·鲍罗丁");
        }
    }
}
