﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace B站大会员解析
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //https://jx.playerjy.com/?url=
                string target = textTarget.Text;
                string tool = "https://jx.playerjy.com/?url=";
                string result = tool + target;
                textResult.Text = result;
            }
            catch { }
        }

        private void buOpenWithBrowser_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start("iexplore", textResult.Text);
            }
            catch { }
        }
        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("V1.0.0\nby Murchey");
        }

        private void 帮助文档ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Help().Show();
        }
    }
}
