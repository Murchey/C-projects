﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonUsedClasses
{
    public class cucMath
    {
        /// <summary>
        /// Sqrt精度为小数点后三位，输出时使用{0:0.000}
        /// </summary>
        /// <param name="n1"></param>
        /// <returns></returns>
        public double Sqrt(int n1) {
            if (n1 == 1)
            {
                double result = 0;
                double Sresult;//result^2
                bool judge;
                do
                {
                    result = result + 0.001;//精度为小数点后三位
                    Sresult = result * result;
                    judge = Sresult <= n1;
                } while (judge);
                return result;
            }
            else
            {
                return 1.0;
            }
        }
        /// <summary>
        /// 两个double类型变量求和
        /// </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns></returns>
        public double Sum(double n1, double n2)
        {
            return n1 + n2;
        }
        /// <summary>
        /// 输入两个整数，返回最大值
        /// </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns></returns>
        public int GetMax(int n1, int n2)
        { 
            int n3=n1>n2?n1:n2;//三元表达式
            return n3;
        }
        /// <summary>
        /// 输入两个整数，返回最小值
        /// </summary>
        /// <param name="n1"></param>
        /// <param name="n2"></param>
        /// <returns></returns>
        public int GetMin(int n1, int n2)
        {
            int n3 = n1 < n2 ? n1 : n2;//三元表达式
            return n3;
        }
        /// <summary>
        /// absolute value求一个整数的绝对值
        /// </summary>
        /// <param name="n1"></param>
        /// <returns></returns>
        public int AbsInt(int n1)//整数绝对值
        {
            if (n1 >= 0)
            {
                return n1;
            }
            else {
                return n1 * -1;
            }
        }
        /// <summary>
        /// absolute value返回小数的绝对值
        /// </summary>
        /// <param name="d1"></param>
        /// <returns></returns>
        public double AbsDouble(double d1)
        {
            if (d1 >= 0)
            {
                return d1;
            }
            else {
                return d1 * -1.0;
            }
        }
    }
}
