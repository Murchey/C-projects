﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonUsedClasses
{
    public class Other
    {
        /// <summary>
        /// 输入整数数列（乱序）可以自动输出顺序数列
        /// </summary>
        /// <param name="str"></param>
        public Array SortStringArray(string str)
        {
            //strArray处理后的字符串数组
            //numArray处理后的整数数组
            string[] strArray= str.Split(' ');//分割字符串，把空格前后的字符分开
            int[] numArray = new int[strArray.Length];
            int temp;
            for (int i = 0; i < strArray.Length; i++)
            {
                temp = Convert.ToInt32(strArray[i]);
                numArray[i] = temp;
                //转换循环
            }
            Array.Sort(numArray);
            return numArray;
        }
    }
}
