﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonUsedClasses;

namespace 字符串的方法
{
    class Program
    {
        static void Main(string[] args)
        {
            
            #region
            string str = Console.ReadLine();// 1 4 7
            string[] strArray = str.Split(' ');//1[0] 4[1] 7[2]
            int[] numArray = new int[strArray.Length];
            //Console.WriteLine(strArray.Length);
            //Console.ReadKey();
            int temp;
            for (int i = 0; i < strArray.Length; i++)
            {
                    temp = Convert.ToInt32(strArray[i]);
                    numArray[i] = temp;
                //转换循环
            }
            Array.Sort(numArray);
            for (int i = 0; i < numArray.Length; i++)
            {
                    Console.Write(numArray[i]+" ");
                //输出循环
            }
            Console.ReadKey();
            #endregion
            CommonUsedClasses.cucMath g= new CommonUsedClasses.cucMath();
            
        }
    }
}
