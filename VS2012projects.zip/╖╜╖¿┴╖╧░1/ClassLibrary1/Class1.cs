﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary1
{
    public class Class1
    {
        static int s(int n1)
        {
            return n1;
        }
        int ns(int n1)
        {
            return n1 + 1;
        }
    }
}
