﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace 方法练习TEST
{
    class Program
    {
        static void Main(string[] args)
        {
            //string str1 = "the first string";
            //string str2 = "the second string";
            //Console.WriteLine(str1 + "\r\n" + str2);
            //Console.ReadKey();


            while (true)
            {
                Console.WriteLine("- loading......Waiting for downloading.");
                Thread.Sleep(50);
                Console.Clear();
                Console.WriteLine("\\ loading......Waiting for downloading.");
                Thread.Sleep(50);
                Console.Clear();
                Console.WriteLine("| loading......Waiting for downloading.");
                Thread.Sleep(50);
                Console.Clear();
                Console.WriteLine("/ loading......Waiting for downloading.");
                Thread.Sleep(50);
                Console.Clear();
            }

            //while (true)
            //{
            //    Console.WriteLine("[□□□□□□□□□□]");//0
            //    Thread.Sleep(100);
            //    Console.Clear();
            //    Console.WriteLine("[■□□□□□□□□□]");//1
            //    Thread.Sleep(100);
            //    Console.Clear();
            //    Console.WriteLine("[■■□□□□□□□□]");//2
            //    Thread.Sleep(100);
            //    Console.Clear();
            //    Console.WriteLine("[■■■□□□□□□□]");//3
            //    Thread.Sleep(100);
            //    Console.Clear();
            //    Console.WriteLine("[■■■■□□□□□□]");//4
            //    Thread.Sleep(100);
            //    Console.Clear();
            //    Console.WriteLine("[■■■■■□□□□□]");//5
            //    Thread.Sleep(100);
            //    Console.Clear();
            //    Console.WriteLine("[■■■■■■□□□□]");//6
            //    Thread.Sleep(100);
            //    Console.Clear();
            //    Console.WriteLine("[■■■■■■■□□□]");//7
            //    Thread.Sleep(100);
            //    Console.Clear();
            //    Console.WriteLine("[■■■■■■■■□□]");//8
            //    Thread.Sleep(100);
            //    Console.Clear();
            //    Console.WriteLine("[■■■■■■■■■□]");//9
            //    Thread.Sleep(100);
            //    Console.Clear();
            //    Console.WriteLine("[■■■■■■■■■■]");//10
            //    Thread.Sleep(100);
            //    Console.Clear();
            //}


        }
    }
}
