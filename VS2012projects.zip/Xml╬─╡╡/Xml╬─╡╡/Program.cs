﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Xml文档
{
    class Program
    {
        static void Main(string[] args)
        {
            ////1.引用命名空间  using System.Xml;
            ////2.创建一个Xml文档
            //XmlDocument doc = new XmlDocument();
            ////3.创建第一行描述信息
            //XmlDeclaration dec= doc.CreateXmlDeclaration("1.0","UTF-8",null);
            ////4.向doc中加入描述信息
            //doc.AppendChild(dec);
            ////xml文档必须有根节点，且只能有一个
            ////5.保存之前要创建一个根节点
            //XmlElement Books= doc.CreateElement("Books");
            ////6.将根节点添加到xml文档中
            //doc.AppendChild(Books);
            ////7.给根节点Books创建子节点
            //XmlElement book1 = doc.CreateElement("book");
            //Books.AppendChild(book1);
            ////8.给book1添加子节点
            ////保存
            //doc.Save("Books.xml");
            //Console.WriteLine("保存完成");
            //Console.ReadKey();



            Console.WriteLine("请输入用户名");
            string username = Console.ReadLine();
            Console.WriteLine("请输入密码");
            string password = Console.ReadLine();

            //create a xml document
            XmlDocument doc=new XmlDocument();
            XmlDeclaration dec=doc.CreateXmlDeclaration("1.0","UTF-8",null);
            doc.AppendChild(dec);
            //create a root element
            XmlElement Users=doc.CreateElement("Users");
            doc.AppendChild(Users);
            //appendchild "username" to xml document

        }
        
        }
    }
}
