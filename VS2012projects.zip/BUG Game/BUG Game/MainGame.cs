﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//开发思路
//每个按钮技能限制使用一次
//新设置一个timer定时减少进度
namespace BUG_Game
{
    public partial class MainGame : Form
    {
        public MainGame()
        {
            InitializeComponent();
        }

        private void MainGame_Load(object sender, EventArgs e)
        {
            PBlog.Maximum = 110;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            MessageBox.Show("项目：学校里的一次月考。\n程序：确保学生规范答题并交卷，返回学生的分数。\n教务处开始提需求：要考语文和数学，高一高二高三分开来考，根据教材出题……\n考务处开始写程序：要出这些题目，给学生分配考号，派监考老师防作弊……\n普通用户行为：填写自己的唯一标识符(考号)，然后答题，交卷(上传)……\n");
        }

        int bu2 = 0;
        int bu3 = 0;
        int bu4 = 0;
        int bu5 = 0;
        int bu6 = 0;
        int bu7 = 0;
        int bu8 = 0;
        int bu9 = 0;
        int bu10 = 0;
        int bu11 = 0;
        int bu12 = 0;

        private void button2_Click(object sender, EventArgs e)
        {
            UseSkills("张三一天之内补考了1024次，把题库记的一清二楚",10,bu2);
            Timer1();
            JudgeN(bu2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            UseSkills("李四填了王五的考号替考。",10,bu3);
            Timer1();
            JudgeN(bu3);
        }
        bool a;
        public void UseSkills(string str,int n,int n1)//按下按钮之后的事件
        {
            try
            {
                if (n1<=2)
                {
                    textBox1.AppendText(str + "\r\n");
                    PBlog.Value += n;
                    if (PBlog.Value >= 120)
                    {
                        PBlog.Value = 110;
                        timer1.Enabled = false;
                    }
                }
                else { }
            }
            catch { }
        }
        public void Timer1()//使进度减少的timer
        {
            a = timer1.Enabled == false;
            if (a)
            {
                timer1.Enabled = true;
            }
            else{}
        }
        public void JudgeN(int n)//一个按钮最多按两次
        {
            if (n >= 1)
            {
                n = 1;
            }
            else {
                n++;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            UseSkills("王六克隆了王七、王八、王九……王一〇二四把考场挤的水泄不通。",15,bu4);
            Timer1();
            JudgeN(bu4);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            UseSkills("小红帮助老师改卷，实则悄悄把自己的成绩改成了100。",10,bu5);
            Timer1(); 
            JudgeN(bu5);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            UseSkills("“春眠不觉晓，_____。”既可以填“处处闻啼鸟”，也可以填“处处闻啼鸟。夜来风雨声，花落知多少”。",0,bu6);
            Timer1();
            JudgeN(bu6);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            UseSkills("小明在上厕所的时候发现办公室没锁门，把批改完的试卷和成绩单烧了",15,bu8);
            Timer1();
            JudgeN(bu8);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            UseSkills("小明在「春眠不觉晓」后面填入「=*/jf‘_,:@0sis8//,/*19_us’sjsk:@」，系统判断小明得分100。",10,bu7);
            Timer1();
            JudgeN(bu7);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            UseSkills("社工攻击：小明请校长喝酒，要到了试卷原题。",10,bu10);
            Timer1();
            JudgeN(bu10);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            UseSkills("老师收卷时滑倒，试卷飞出去找不到了",10,bu9);
            Timer1();
            JudgeN(bu9);
        }

        private void button11_Click(object sender, EventArgs e)
        {
            UseSkills("老师需要3天的时间改试卷，这3天响应速度很慢。",10,bu11);
            Timer1();
            JudgeN(bu11);
        }

        private void button12_Click(object sender, EventArgs e)
        {
            UseSkills("小明在试卷头和尾各画了两道斜线，试卷消失了，变成了考场须知",10,bu12);
            Timer1();
            JudgeN(bu12);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            try
            {
                if (PBlog.Value == 110)
                {
                    label6.Text = "YOU WIN";
                }
                else
                {
                    PBlog.Value -= 5;
                }
            }
            catch { }
        }
    }
}
