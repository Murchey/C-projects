﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 飞行棋游戏
{
    class Program
    {
        //1.画游戏初始界面
        //2.初始游戏地图
        //3.绘制地图
        //4.玩游戏
        static int[] Maps = new int[100];//地图数组
        static int[] PlayerPos = new int[2];//玩家A和B的坐标
        static string[] PlayerNames = new string[2];//存储两个玩家的昵称
        static bool[] flags = new bool[2];//储存两个玩家的标记（暂停一回合要用到）
        
        static void Main(string[] args)
        {
            GameShow();//绘制游戏初始界面
            #region 输入玩家昵称
            Console.WriteLine("请输入玩家A的昵称");
            PlayerNames[0] = Console.ReadLine();
            while (PlayerNames[0] == "") 
            {
                Console.WriteLine("玩家A昵称不能为空，请重新输入");
                PlayerNames[0] = Console.ReadLine();
            }//while
            Console.WriteLine("请输入玩家B的昵称");
            PlayerNames[1] = Console.ReadLine();
            while(PlayerNames[1]==""||PlayerNames[1]==PlayerNames[0])
            {
                if (PlayerNames[1] == "")
                {
                    Console.WriteLine("玩家B昵称不能为空，请重新输入");
                    PlayerNames[1] = Console.ReadLine();
                }//if
                else {
                    Console.WriteLine("玩家B昵称不能与玩家A昵称相同，请重新输入");
                    PlayerNames[1] = Console.ReadLine();
                }//else
            }//while
            #endregion
            //玩家输入完昵称后清屏，开始游戏
            Console.Clear();//清屏
            GameShow();
            #region 玩家图例
            Console.WriteLine("{0}的玩家位置用A表示",PlayerNames[0]);
            Console.WriteLine("{0}的玩家位置用B表示", PlayerNames[1]);
            #endregion
            InitailMap();//初始化地图
            DrawMap();//画地图
            while(PlayerPos[0]<99 && PlayerPos[1]<99)//AB中任一玩家不到终点就不停止
            {
                if (flags[0] == false)
                {
                    PlayGame(0);//玩游戏过程
                }//if
                else 
                {
                    flags[0] = false;//重置玩家状态
                }//else

                if (PlayerPos[0] >= 99)
                {
                    Console.WriteLine("玩家{0}无耻的赢了玩家{1}",PlayerNames[0],PlayerNames[1]);
                    break;
                }

                if (flags[1] == false)
                {
                    PlayGame(1);
                }//if
                else 
                {
                    flags[1] = false;
                }//else

                if (PlayerPos[0] >= 99)
                {
                    Console.WriteLine("玩家{0}无耻的赢了玩家{1}", PlayerNames[1], PlayerNames[0]);
                    break;
                }
            }//while
            win();
            Console.ReadKey();
        }
        public static void GameShow()//绘制游戏初始界面的方法
        {
            Console.ForegroundColor=ConsoleColor.Yellow;//调整文字颜色
            Console.WriteLine("************************");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("************************");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("************************");
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("*****飞行棋游戏v1.1*****");
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("************************");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("************************");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("************************");
        }
        public static void InitailMap()
        {
        int[] luckyturn = {6,23,40,59,69,83};//幸运轮盘☆
        for (int i = 0; i < luckyturn.Length; i++)
        {
            Maps[luckyturn[i]] = 1;
        }
        int[] landMine = { 5, 13, 17, 33, 38, 50, 64, 80, 94 };//地雷 ▽
        for (int i = 0; i < landMine.Length; i++)
        {
            Maps[landMine[i]] = 2;
        }
        int[] pause = { 9, 27, 60, 93 };//暂停※
        for (int i = 0; i < pause.Length; i++)
        {
            Maps[pause[i]] = 3;
        }
        int[] timeTunnel = {20,25,45 ,63,72,88,90};//时空隧道■
        for (int i = 0; i < timeTunnel.Length; i++)
        {
            Maps[timeTunnel[i]] = 4;
        }
        }//初始化地图
        public static void DrawMap()//画地图
        {
            Console.WriteLine("图例：AB在同一位置<> 幸运轮盘☆ 地雷▽ 暂停※ 时空隧道■");
            #region 第一横行
            for (int i = 0; i < 30; i++)
            {
                Console.Write(DrawStringMap(i));//画关卡
            } 
            Console.WriteLine();//画完第一行后应该换行
            #endregion
            #region 第一竖行
            for (int i = 30; i < 35; i++)
            {
                for (int j = 0; j <=28 ; j++)//用空格填充地图空白部分
                {
                    Console.Write("  ");
                }
                Console.Write(DrawStringMap(i));//画关卡
                Console.WriteLine();//画完一个竖列单元格后应该换行
            }
            #endregion
            #region 第二横行
            for (int i = 64; i >=35; i--)
            {
                Console.Write(DrawStringMap(i));//画关卡
            }
            Console.WriteLine();//第二横行画完后应该换行
            #endregion
            #region 第二竖行
            for (int i = 65; i <= 69; i++)
            {
                Console.WriteLine(DrawStringMap(i));//画关卡
            }
            #endregion
            #region 第三横行
            for (int i = 70; i <=99; i++)
            {
                Console.Write(DrawStringMap(i));
            }
            Console.WriteLine();//画完最后一行应换一行
#endregion
        }//DrawMap
        public static string DrawStringMap(int i)//画关卡
        {
            string str = "";//空字符串用于返回值,尽量不在方法中出现console.write
                //玩家A和B的坐标相同，并且都在同一地图上画"<>"
                if (PlayerPos[0]==PlayerPos[1]&&PlayerPos[0]==i)
                {
                str="<>";
                }
                //AB坐标不同时，分别画A、B
                else if (PlayerPos[0] == i)
                {
                    str="A";
                }
                else if (PlayerPos[1] == i)
                {
                    str="B";
                }
                else 
                {
                    switch (Maps[i]) 
                    {
                        case 0:
                            Console.ForegroundColor = ConsoleColor.White;
                            str="□";
                            break;
                        case 1:
                            Console.ForegroundColor = ConsoleColor.Red;
                            str="☆";//幸运轮盘☆
                            break;
                        case 2:
                            Console.ForegroundColor = ConsoleColor.Blue;
                            str="▽";//地雷▽
                            break;
                        case 3:
                            Console.ForegroundColor = ConsoleColor.Yellow;
                            str="※";//暂停※
                            break;
                        case 4:
                            Console.ForegroundColor = ConsoleColor.Green;
                            str="■";//时空隧道■
                            break;
                    }//switch
                }//else
                return str;//返回关卡图标
          }//DrawStringMap
        public static void PlayGame(int PlayerNumber) //玩游戏过程
        {
            Random r = new Random();
            int rNumber = r.Next(1,7);//掷骰子过程用随机数模拟
            Console.WriteLine("{0}按任意键开始掷骰子",PlayerNames[PlayerNumber]);
            Console.ReadKey(true);
            Console.WriteLine("{0}掷出了{1}",PlayerNames[PlayerNumber],rNumber);
            PlayerPos[PlayerNumber] += rNumber;
            ChangePos();
            Console.ReadKey(true);
            Console.WriteLine("{0}按下任意键开始行动",PlayerNames[PlayerNumber]);
            Console.ReadKey(true);
            Console.WriteLine("{0}行动完了",PlayerNames[PlayerNumber]);
            //玩家A可能踩到玩家B 时空隧道 幸运轮盘 地雷 暂停 方块
            if (PlayerPos[PlayerNumber] == PlayerPos[1 - PlayerNumber])
            {
                Console.WriteLine("玩家{0}踩到了玩家{1}，玩家{2}退六格", PlayerNames[PlayerNumber], PlayerNames[1 - PlayerNumber], PlayerNames[1 - PlayerNumber]);
                PlayerPos[1 - PlayerNumber] -= 6;
                ChangePos();
                Console.WriteLine("按下任意键刷新地图");
                Console.ReadKey(true);
            }//if
            else //踩到了关卡
            {
                //玩家的坐标0 1 2 3 4

                switch(Maps[PlayerPos[PlayerNumber]])
                {
                    case 0://方块 无特殊作用
                        Console.WriteLine("玩家{0}踩到了方块，安全",PlayerNames[PlayerNumber]);
                        Console.WriteLine("按下任意键刷新地图");
                        Console.ReadKey(true);
                        break;
                    case 1://幸运轮盘 选择
                        Console.WriteLine("玩家{0}踩到了幸运轮盘，请选择 1--交换位置 2--轰炸对方",PlayerNames[PlayerNumber]);
                        string input = Console.ReadLine();
                        while (true) 
                        {
                            if (input=="1")
                            {
                                Console.WriteLine("玩家{0}和玩家{1}互换位置",PlayerNames[PlayerNumber],PlayerNames[1-PlayerNumber]);
                                Console.ReadKey(true);
                                int temp=PlayerPos[PlayerNumber];
                                PlayerPos[PlayerNumber]=PlayerPos[1-PlayerNumber];
                                PlayerPos[1-PlayerNumber] = temp;
                                ChangePos();
                                Console.WriteLine("交换完成，按任意键继续游戏！");
                                Console.ReadKey(true);
                                break;
                            }//if
                            else if (input == "2")
                            {
                                Console.WriteLine("玩家{0}轰炸玩家{1}，玩家{2}退六格",PlayerNames[PlayerNumber], PlayerNames[1 - PlayerNumber],PlayerNames[1 - PlayerNumber]);
                                Console.ReadKey(true);
                                PlayerPos[1-PlayerNumber]-=6;
                                ChangePos();
                                Console.WriteLine("玩家{0}退了六格",PlayerNames[1-PlayerNumber]);
                                Console.WriteLine("按下任意键刷新地图");
                                Console.ReadKey(true);
                                break;
                            }//else if
                            else
                            {
                                Console.WriteLine("只能输入1或2，1--交换位置 2--轰炸对方");
                                input=Console.ReadLine();
                            }//esle
                        }//while
                        break;
                    case 2://地雷 -6
                        Console.WriteLine("玩家{0}踩到地雷，退6格",PlayerNames[PlayerNumber]);
                        PlayerPos[PlayerNumber]-=6;
                        ChangePos();
                        Console.WriteLine("按下任意键刷新地图");
                        Console.ReadKey(true);
                        break;
                    case 3://暂停 一回合
                        Console.WriteLine("玩家{0}踩到暂停，暂停一回合",PlayerNames[PlayerNumber]);
                        flags[PlayerNumber] = true;
                        Console.WriteLine("按下任意键刷新地图");
                        Console.ReadKey(true);
                        break;
                    case 4://时空隧道 +10
                        Console.WriteLine("玩家{0}踩到时空隧道，前进10格",PlayerNames[PlayerNumber]);
                        PlayerPos[PlayerNumber]+=10;
                        ChangePos();
                        Console.WriteLine("按下任意键刷新地图");
                        Console.ReadKey(true);
                        break;
                }//switch
            }//else
            ChangePos();//本行代码可以代替上方过程中的ChangePos();
            Console.Clear();
            DrawMap();
        }//PlayGame
        public static void ChangePos()//防止卡出地图，改变坐标时候使用
        {
            if (PlayerPos[0] < 0)
            {
                PlayerPos[0] = 0;
            }
            if (PlayerPos[0] > 99)
            {
                PlayerPos[0] = 99;
            }
            //上方为玩家A的
            if (PlayerPos[1] < 0)
            {
                PlayerPos[1] = 0;
            }
            if (PlayerPos[1] > 99)
            {
                PlayerPos[1] = 99;
            }
            //上方为玩家B的
        }//ChangePos
        public static void win() 
        {
Console.WriteLine("YYYYYYYY        YYYYYYYY    EEEEEEEEEEEEEEEEEE      SSSSSSSSSSS");
Console.WriteLine("YYYYYYYY        YYYYYYYY    EEEEEEEEEEEEEEEEEE     SSSSSSSSSSSSS");
Console.WriteLine("YYYYYYYY        YYYYYYYY    EEEEEEEEEEEEEEEEEE    SSSSSSSSSSSSSSS");
Console.WriteLine("YYYYYYYY        YYYYYYYY    EEEEEEEEEEEEEEEEEE    SSSSSSSS    SSS");
Console.WriteLine(" YYYYYYYY      YYYYYYYY     EEEEEEEE              SSSSSSSS");
Console.WriteLine("  YYYYYYYY    YYYYYYYY      EEEEEEEE              SSSSSSSS");
Console.WriteLine("   YYYYYYYY  YYYYYYYY       EEEEEEEEEEEEE          SSSSSSSS");
Console.WriteLine("    YYYYYYYYYYYYYYYY        EEEEEEEEEEEEE           SSSSSSSSSS");
Console.WriteLine("     YYYYYYYYYYYYYY         EEEEEEEEEEEEE            SSSSSSSSSS");
Console.WriteLine("      YYYYYYYYYYYY          EEEEEEEEEEEEE               SSSSSSSSS");
Console.WriteLine("       YYYYYYYYYY           EEEEEEEE                     SSSSSSSS");
Console.WriteLine("        YYYYYYYY            EEEEEEEE                     SSSSSSSS");
Console.WriteLine("        YYYYYYYY            EEEEEEEEEEEEEEEEE     SSS    SSSSSSSS");
Console.WriteLine("        YYYYYYYY            EEEEEEEEEEEEEEEEE     SSSSSSSSSSSSSSS");
Console.WriteLine("        YYYYYYYY            EEEEEEEEEEEEEEEEE      SSSSSSSSSSSSS");
        }//win

    }
}