﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Alarm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void 界面ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("V1.0.0 BY Murchey","Alarm");
        }

        private void 退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToLongTimeString().ToString();//获得24小时制的时间
            //获得十二小时制的时间
            //DateTime.Now.ToString("hh:mm:ss");
            label2.Text = DateTime.Now.ToString("yyyy-MM-dd");//获得日期
        }

        private void 暗色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void 显示字体ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 字体默认黑体大小72ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            fd.ShowDialog();
            label1.Font = fd.Font;
            label2.Font = fd.Font;
        }

        private void 颜色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            label1.ForeColor = cd.Color;
            label2.ForeColor = cd.Color;
        }

        private void 英文ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            设置ToolStripMenuItem.Text = "Settings";
            功能ToolStripMenuItem.Text = "Fuctions";
            外观ToolStripMenuItem.Text = "Appearance";
            显示字体ToolStripMenuItem.Text = "Fonts";
            字体默认黑体大小72ToolStripMenuItem.Text = "Seting Font";
            颜色ToolStripMenuItem.Text = "Font Color";
            语言ToolStripMenuItem.Text = "Language";
            中文简体ToolStripMenuItem.Text = "Chinese(Simplified)";
            英文ToolStripMenuItem.Text = "English";
 
            退出ToolStripMenuItem.Text = "Quit";
            关于ToolStripMenuItem.Text = "About";
            正计时ToolStripMenuItem.Text="Positive Timing";
            倒计时ToolStripMenuItem.Text = "Count Down";

        }

        private void 中文简体ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            设置ToolStripMenuItem.Text = "设置";
            功能ToolStripMenuItem.Text = "功能";
            外观ToolStripMenuItem.Text = "外观";
            显示字体ToolStripMenuItem.Text = "显示字体";
            字体默认黑体大小72ToolStripMenuItem.Text = "字体默认黑体大小";
            颜色ToolStripMenuItem.Text = "颜色";
            语言ToolStripMenuItem.Text = "语言";
            中文简体ToolStripMenuItem.Text = "中文简体";
            英文ToolStripMenuItem.Text = "英文";

            退出ToolStripMenuItem.Text = "退出";
            关于ToolStripMenuItem.Text = "关于";
            正计时ToolStripMenuItem.Text = "正计时";
            倒计时ToolStripMenuItem.Text = "倒计时";

        }

        private void 正计时ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(".\\计时器.exe");
            }
            catch { MessageBox.Show("程序组件丢失‘计时器.exe‘"); }
        }

        private void 倒计时ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                Process.Start(".\\倒计时.exe");
            }
            catch { MessageBox.Show("程序组件丢失‘倒计时.exe‘"); }
        }
    }
}
