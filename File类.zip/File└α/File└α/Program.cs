﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace File类
{
    class Program
    {
        static void Main(string[] args)
        {
            #region 程序开启主菜单选项
            BanBen();
            Console.WriteLine("请选择本程序执行的操作  1--写入文本文件  2--读取文本文件  3--更改文件格式");
            string MainChoice = Console.ReadLine();
            ChoiceJudge(MainChoice);
            #endregion
            if (MainChoice == "1")
            {
                #region 获取文件内容和文件名
                Console.WriteLine("请输入文件名");
                string name = Console.ReadLine();
                Console.WriteLine("请输入要想文件中写入的内容");
                string texts = Console.ReadLine();
                #endregion
                #region 选择文件格式
                Console.WriteLine("请选择文件的格式：1--文本文件   2--本程序格式（无法用系统自带软件打开）  3--自定义格式");
                string ExtensionChoices = Console.ReadLine();
                ChoiceJudge(ExtensionChoices);
                #endregion
                #region 进行文件操作
                if (ExtensionChoices == "1")
                {
                    string FileName = name + ".txt";
                    WriteFile(FileName, texts);
                }//if
                else if (ExtensionChoices == "2")
                {
                    string FileName = name + ".ue";
                    WriteFile(FileName, texts);
                }//else if
                else
                {
                    Console.WriteLine("请输入你想自定义的格式，格式前不用加 ’.‘ ");
                    string Extension = Console.ReadLine();
                    string FileName = name + "." + Extension;
                    WriteFile(FileName, texts);
                }//else
                #endregion
            }//if
            else if (MainChoice == "3")
            {
                #region 确定文件名称及是否存在
                Console.WriteLine("请将想更改格式的文件放入本程序同文件夹下，并输入文件名（请包括后缀名，如1.txt）");
                Console.WriteLine("或者你可以输入文件的绝对路径（请包括后缀名，如1.txt）");
                string BeforeFilePath = Console.ReadLine();
                Console.WriteLine("请输入更改后的文件名（不要包括后缀名，如 1）");
                string AfterFileNameWithoutExtension = Console.ReadLine();
                //AfterFileNameWithoutExtension不包括扩展名的文件名
                FileExistsOrNot(BeforeFilePath);
                #endregion
                #region 确定文件更改后的格式并移动文件
                Console.WriteLine("请选择文件格式  1--TXT文本文件   2--UE非直读文件  3--自定义格式");
                string AFEC = Console.ReadLine();//AFEC=AfterFileExtensionChoice
                ChoiceJudge(AFEC);
                if (AFEC == "1")
                {
                    string ChangeExtension = ".txt";
                    string AfterFileName = AfterFileNameWithoutExtension + ChangeExtension;
                    File.Move(BeforeFilePath, AfterFileName);
                }//if
                else if (AFEC == "2")
                {
                    string ChangeExtension = ".ue";
                    string AfterFileName = AfterFileNameWithoutExtension + ChangeExtension;
                    File.Move(BeforeFilePath, AfterFileName);
                }//else if
                else 
                {
                    Console.WriteLine("请输入文件格式（全英文），不加‘.’");
                    string ChangeExtension = Console.ReadLine();
                    string AfterFileName = AfterFileNameWithoutExtension + "."+ChangeExtension;
                    File.Move(BeforeFilePath, AfterFileName);
                }//else
                Console.WriteLine("操作已完成,文件已移动至与本软件同目录下");
                Console.ReadKey();
                #endregion
            }//else if
            else
            {
                #region 读取文件
                Console.WriteLine("请将文件移动至和本软件相同文件夹下，并输入文件名");
                string Path = Console.ReadLine();
                FileExistsOrNot(Path);
                Console.WriteLine("文件内容如下：");
                Console.WriteLine(File.ReadAllText(Path, Encoding.UTF8));
                Console.ReadKey();
                #endregion
            }//else
        }
        public static void WriteFile(string FileName,string texts)
        {
            Console.WriteLine("文件默认写入到应用程序所在文件夹目录中");
            Console.WriteLine("文件名是{0}", FileName);
            File.WriteAllText(FileName, texts);
            Console.WriteLine("写入完成");
            Console.ReadKey();
        }//写入文件操作
        public static void BanBen()
        {
            Console.WriteLine("U.E.-M.E.  版本：V1.3");
            Console.WriteLine("所有内容输入完成后按回车（Enter），暂时不支持多行文本输入");
            Console.WriteLine("支持自定义格式和txt文本文件的读写");
            Console.WriteLine();
        }//版本说明
        public static void FileExistsOrNot(string FileName)
        {
            if (File.Exists(FileName))
            {
                Console.WriteLine("已通过验证：文件存在");
                Console.WriteLine();
            }//if
            else{
                Console.WriteLine("未通过验证：文件不存在！请重新确定文件位置，并重新开启软件");
                Console.WriteLine();
            }//else
        }//判断文件是否存在
        public static void ChoiceJudge(string Choice)//选项有效性判断
        {
            while (Choice == "" || !(Choice == "1" || Choice == "2" || Choice == "3"))
            {
                Console.WriteLine("输入的选项为或不正确，请重新输入");
                Choice=Console.ReadLine();
            }//while
        }
    }
}
