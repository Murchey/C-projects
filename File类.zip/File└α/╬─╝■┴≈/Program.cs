﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 文件流
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"C:\Users\86183\Desktop\2022年高一网课资料\历史\第19课辛亥革命2022.pptx";
            string target = @"C:\Users\86183\Desktop\历史19课课件.pptx";
            FileCopy(path, target);
            Console.WriteLine("操作完成");
            Console.ReadKey();
        }
        public static void FileCopy(string path, string target)
        { 
        using(FileStream fsRead=new FileStream(path,FileMode.Open,FileAccess.Read))//创建负责读取的文件流
        {
            using(FileStream fsWrite=new FileStream(target,FileMode.OpenOrCreate,FileAccess.Write))//创建负责写入的文件流
            {
                byte[] buffer = new byte[1024*1024*5];//创建5MB的缓存空间
                int r;
                while (true)
                {
                    r = fsRead.Read(buffer, 0, buffer.Length);
                    fsWrite.Write(buffer,0,r);
                    if (r == 0)
                    { 
                        break;
                    }//if
                }//while
            }//write
        }//read
        }
    }
}
