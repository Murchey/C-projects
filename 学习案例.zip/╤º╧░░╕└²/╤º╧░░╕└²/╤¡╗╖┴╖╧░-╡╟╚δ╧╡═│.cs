﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 学习案例
{
    class Program
    {
        static void Main(string[] args)
        {
            //TITLE : 循环练习-登入系统
           
                Console.WriteLine("Type the username(A)");
                string username = Console.ReadLine();
                bool a = username == "A";
                if (a)
                {
                    Console.WriteLine("Type password(12345)");
                    string password = Console.ReadLine();
                    bool b = password == "12345";
                    if (b)
                    {
                        Console.WriteLine("Login Succeed");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("Wrong password");
                        Console.ReadKey();
                    }
                }
                else
                {
                    Console.WriteLine("Cannot find the username");
                    Console.ReadKey();
                }
            }
        }
    }
