﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Unsquare
{
    class 开方
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Please type a number");
                string a = Console.ReadLine();//获取根号下的数
                int aa = Convert.ToInt32(a);//转换为int类型
                if (aa <= 0)
                {
                    Console.WriteLine("请输入大于零的数！");
                    Console.ReadKey();
                }//判断该数是否小于等于0，如果是，则不执行
                else
                {
                    double b = 0;//开出来的数
                    double bb = 0;//开出来的数的平方
                    bool c;//判断 开出来数的平方 是否小于 根号下的数 的布尔量
                    do
                    {
                        b = b + 0.001;
                        bb = b * b;
                        c = (bb < aa);//递增，每增加0.001判断一次数是否符合要求

                    }
                    while (c);//如果开出来数的平方 大于了 根号下的数 则退出循环
                    b = b - 0.001;//减去0.001获得准确值
                    Console.WriteLine("根号下{0},约为{1:0.000}", a, b);//打印结果，并保留三位小数
                    Console.ReadKey();
                }
            }
            catch
            {
                Console.WriteLine("请输入整数！");//对于不符合运算类型的数进行提醒
                Console.ReadKey();
            }
        }
    }
}
