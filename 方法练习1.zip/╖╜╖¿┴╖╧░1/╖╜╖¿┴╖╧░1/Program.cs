﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 方法练习1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                //输入两个整数，返回最大的
                Console.WriteLine("输入两个整数，返回最大的");
                int n1 = Convert.ToInt32(Console.ReadLine());
                int n2 = Convert.ToInt32(Console.ReadLine());
                int Max = GetMax(n1, n2);
                Console.WriteLine(Max);
                Console.ReadKey();
            }
            catch {
                Console.WriteLine("请输入有效整数");
                Console.ReadKey();
            }
        }
        public static int GetMax(int n1, int n2)
        {
            int Max = n1 > n2 ? n1 : n2;
            return (Max);
        }
    }
}
