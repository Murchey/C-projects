﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 字符串的方法
{
    class Program
    {
        static void Main(string[] args)
        {

           Console.WriteLine( Math.Sqrt(10));
           Console.ReadKey();
        }
    }
}
