﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Claer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Clear-By Murchey";
            try
            {
                #region 生成格式化配置文件
                if (File.Exists("targets.ini"))
                {
                    Console.WriteLine("文件已在当前目录存在，若需要带注释的配置文件，请删除当前目录的’targets.ini‘并重启软件");
                    Console.WriteLine("请使用UTF-8模式编辑");
                }
                else {
                    
                    string[] texts = {"## 此软件by Murchey, 软件版本V1.0",
                                      "## 请在下方写入文件目录",
                                      "## 删除当前文件夹的文件或文件夹请输入’.\\文件名或文件夹名‘文件名需要包含后缀",
                                      "## 删除非当前目录的文件需输入文件的绝对地址",
                                      "## 写入注释需要另开新行，注释行首需要两个##符号",
                                      "## 该软件的解释和创作权归作者本人"
                                      };
                    File.WriteAllLines("targets.ini",texts,Encoding.UTF8);
                }
                #endregion
                Console.WriteLine("是否清除目标？（Y/N）---配置目标请修改targets.ini文件，该文件已在当前目录生成");
                string answer = Console.ReadLine();//执行操作前的询问
                #region 注释判别
                if (answer == "Y" || answer == "y")
                {
                    string[] targets = File.ReadAllLines("targets.ini");//以数组方式存储每个需要删除文件的路径
                    //如果数组中某一个字符串开头为##则判别为注释
                    for (int i = 0; i <targets.Length; i++)
                    {
                        if (targets[i].Substring(0, 1) == "##")
                        {
                            targets[i].Remove(0,targets[i].Length);
                        }
                    }
                #endregion
                    Console.WriteLine("请等待操作执行完毕......");
                #region 删除操作
                    for (int i = 0; i < targets.Length; i++)
                    {
                        try
                        {
                            FileAttributes attr = File.GetAttributes(targets[i]);//取得文件路径的文件类型
                            if (attr == FileAttributes.Directory)
                            {
                                Directory.Delete(targets[i], true);//删除文件夹操作
                                //Delete(String, Boolean)	
                                //if (boolean==true), 删除指定的目录，并删除该目录中的所有子目录和文件
                            }
                            else
                            {
                                File.Delete(targets[i]);//删除文件操作
                            }
                        }
                        catch 
                        { }//这个try-catch是为了不报错，只删除非注释文件路径
                    }
                    Console.WriteLine("已删除！");//结束语
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("操作取消");//未执行操作结束语
                    Console.ReadKey();
                }
                    #endregion
            }
            #region 报错提示
            catch {
                Console.WriteLine("未检测到文件‘targets.ini’操作不能被执行");
                Console.WriteLine("或者不能删除文件");
                Console.ReadKey();//报错
            }
            #endregion
        }
    }
}
