﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 性价比计算器
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("程序只允许设置一次权重，如要重新设置请重启软件");
                Console.WriteLine("输入CPU权重(整数)");
                int CPUweight = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("输入GPU权重(整数)");
                int GPUweight = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("输入RAM权重(整数)");
                int RAMweight = Convert.ToInt32(Console.ReadLine());

                while (true)
                {
                    Console.WriteLine("输入CPU算力");
                    double CPUability = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("输入GPU算力");
                    double GPUability = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("输入RAM大小");
                    double RAMability = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("输入价格大小");
                    double Price = Convert.ToDouble(Console.ReadLine());


                    double Result = ((CPUweight / 10) * CPUability + (GPUweight / 10) * GPUability + (RAMweight / 10) * RAMability) / Price;
                    Console.WriteLine("结果是{0}",Result);
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.ReadKey();
                
                
                }
            }
            catch { Console.WriteLine("Error!"); Console.ReadKey(); }


        }
    }
}
