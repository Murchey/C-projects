﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Key;

namespace Message
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Key.mes k = new Key.mes();
                k.ShowMes();
                Key.taw k1 = new Key.taw();
                k1.ShowTAW();
            }
            catch 
            {
            Console.WriteLine("未检测到“Key.dll”无法显示信息");
            Console.ReadKey();
            }
        }
    }
}
