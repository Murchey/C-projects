﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace SimplifyXml
{
    public class Xml
    {
        /// <summary>
        /// 创建一个XML文件对象，并添加描述内容，返回一个XmlDocument
        /// </summary>
        /// <returns></returns>
        public XmlDocument CreateXmlDoucment()
        {
            XmlDocument doc = new XmlDocument();
            XmlDeclaration dec = doc.CreateXmlDeclaration("1.0","UTF-8",null);
            doc.AppendChild(dec);
            return doc;
        }
        /// <summary>
        /// 创建根节点，返回XmlElement
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="RootName"></param>
        /// <returns></returns>
        public XmlElement AppendRootNode(XmlDocument doc, string RootName)
        {
            XmlElement r = doc.CreateElement(RootName);
            doc.AppendChild(r);
            return r;
        }
        /// <summary>
        /// 创建子节点，返回XmlElement
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="RootName"></param>
        /// <param name="ChildName"></param>
        /// <returns></returns>
        public XmlElement AppendChildNode(XmlDocument doc,XmlElement RootName,string ChildName)
        {
            XmlElement r = doc.CreateElement(ChildName);
            RootName.AppendChild(r);
            return r;
        }
        /// <summary>
        /// 改变标签内的内容
        /// </summary>
        /// <param name="r"></param>
        /// <param name="InnerText"></param>
        public void ChangeNodeInnerText(XmlElement r, string InnerText)
        {
            r.InnerText = InnerText;
        }
        /// <summary>
        /// 设置属性，并且有属性内容
        /// </summary>
        /// <param name="r"></param>
        /// <param name="AttributeName"></param>
        /// <param name="AttributeValue"></param>
        public void SetAttribute(XmlElement r, string AttributeName, string AttributeValue)
        {
            r.SetAttribute(AttributeName,AttributeValue);
        }
        /// <summary>
        /// 设置一个无内容的属性
        /// </summary>
        /// <param name="r"></param>
        /// <param name="AttributeName"></param>
        public void SetAttribute(XmlElement r, string AttributeName)
        {
            r.SetAttribute(AttributeName, null);
        }
        /// <summary>
        /// 保存XML文件
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="FileName"></param>
        public void SaveXml(XmlDocument doc, string FileName)
        {
            doc.Save(FileName+".xml");
        }
    }
}
