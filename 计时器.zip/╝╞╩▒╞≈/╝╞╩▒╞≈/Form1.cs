﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 计时器
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void buStart_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void buStop_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }

        private void buClear_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            labelHour.Text = "00";
            labelSecond.Text = "00";
            labelMinute.Text = "00";

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            #region 时分秒转整数类型变量
            int second = Convert.ToInt32(labelSecond.Text);
            int minute = Convert.ToInt32(labelMinute.Text);
            int hour = Convert.ToInt32(labelHour.Text);
            #endregion
            #region 进位
            second ++ ;
            labelSecond.Text = second.ToString();
            if (second == 60)
            {
                minute++;
                second = 0;
                labelSecond.Text = second.ToString();
                labelMinute.Text = minute.ToString();
            }
            if (minute == 60)
            {
                hour++;
                minute = 0;
                second = 0;
                labelSecond.Text = second.ToString();
                labelMinute.Text = minute.ToString();
                labelHour.Text = hour.ToString();
            #endregion
            }
        }

        private void labelMinute_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void labelSecond_Click(object sender, EventArgs e)
        {

        }

        public void Form1_Load(object sender, EventArgs e)
        {
            
            //#region 时分秒转整数类型变量
            //int second = Convert.ToInt32(labelSecond.Text);
            //int minute = Convert.ToInt32(labelMinute.Text);
            //int hour = Convert.ToInt32(labelHour.Text);
            //#endregion
            //            #region 进位
            //second ++ ;
            //labelSecond.Text = second.ToString();
            //if (second == 60)
            //{
            //    minute++;
            //    second = 0;
            //    labelSecond.Text = second.ToString();
            //    labelMinute.Text = minute.ToString();
            //}
            //if (minute == 60)
            //{
            //    hour++;
            //    minute = 0;
            //    second = 0;
            //    labelSecond.Text = second.ToString();
            //    labelMinute.Text = minute.ToString();
            //    labelHour.Text = hour.ToString();
            //#endregion
        }
    }
}
