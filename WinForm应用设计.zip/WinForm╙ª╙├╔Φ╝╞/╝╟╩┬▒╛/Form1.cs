﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 记事本
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void buOpenFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "选择一个文件";//标题
            ofd.Multiselect=true;//多选
            ofd.Filter="文本文件|*.txt|UE非直读文件|*.ue|所有文件|*.*";//显示文件类型
            ofd.ShowDialog();//展示对话框
            string path = ofd.FileName;//路径
            if (path == "")
            {
                return;
            }//if
                using (FileStream fsRead = new FileStream(path, FileMode.Open,FileAccess.Read))
                {
                    byte[] buffer = new byte[1024 * 1024 * 5];
                    int r = fsRead.Read(buffer, 0, buffer.Length);
                    textBox1.Text = Encoding.UTF8.GetString(buffer, 0, r);
                }//using
        }

        private void buSaveFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Title = "选择保存位置";
            sfd.Filter = "文本文件|*.txt|UE非直读文件|*.UE|所有文件|*.*";
            sfd.ShowDialog();
            string path = sfd.FileName;
            if (path == "")
            {
                return;
            }//if
            using (FileStream fsWrite = new FileStream(path, FileMode.OpenOrCreate,FileAccess.Write))
            { 
            byte[] buffer=Encoding.UTF8.GetBytes(textBox1.Text);
            fsWrite.Write(buffer,0,buffer.Length);
            }//using
            MessageBox.Show("已保存");
        }

        private void buFont_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            fd.ShowDialog();
            textBox1.Font = fd.Font;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            textBox1.ForeColor = cd.Color;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private void 打开ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title = "选择一个文件";//标题
            ofd.Multiselect = true;//多选
            ofd.Filter = "文本文件|*.txt|UE非直读文件|*.ue|所有文件|*.*";//显示文件类型
            ofd.ShowDialog();//展示对话框
            string path = ofd.FileName;//路径
            if (path == "")
            {
                return;
            }//if
            using (FileStream fsRead = new FileStream(path, FileMode.Open))
            {
                byte[] buffer = new byte[1024 * 1024 * 5];
                int r = fsRead.Read(buffer, 0, buffer.Length);
                textBox1.Text = Encoding.UTF8.GetString(buffer, 0, r);
            }//using
        }

        private void 保存ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Title = "选择保存位置";
            sfd.Filter = "文本文件|*.txt|UE非直读文件|*.UE|所有文件|*.*";
            sfd.ShowDialog();
            string path = sfd.FileName;
            if (path == "")
            {
                return;
            }//if
            using (FileStream fsWrite = new FileStream(path, FileMode.OpenOrCreate, FileAccess.Write))
            {
                byte[] buffer = Encoding.UTF8.GetBytes(textBox1.Text);
                fsWrite.Write(buffer, 0, buffer.Length);
            }//using
            MessageBox.Show("已保存");
        }

        private void 字体ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fd = new FontDialog();
            fd.ShowDialog();
            textBox1.Font = fd.Font;
        }

        private void 文本颜色ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            textBox1.ForeColor = cd.Color;
        }

        private void 自动换行ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (自动换行ToolStripMenuItem.Text == "自动换行")
            {
                自动换行ToolStripMenuItem.Text = "取消自动换行";
                textBox1.WordWrap = true;
            }
            else if (自动换行ToolStripMenuItem.Text == "取消自动换行")
            {
                自动换行ToolStripMenuItem.Text = "自动换行";
                textBox1.WordWrap = false;
            }
        }
        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("V1.1.0\nby Murchey","Personal Work");
        }

        private void 强制退出ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void 文件ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
         
            timeToolStripMenuItem.Text = DateTime.Now.ToString();
        }

        private void darkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.FromArgb(45, 45, 48);
            textBox1.ForeColor = Color.FromArgb(255,255,255);
            menuStrip1.BackColor = Color.FromArgb(45, 45, 48);
            menuStrip1.ForeColor = Color.FromArgb(225,225,225);
        }

        private void brightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.FromArgb(254, 254, 254);
            textBox1.ForeColor = Color.FromArgb(0, 0, 0);
            menuStrip1.BackColor = Color.FromArgb(245, 245, 248);
            menuStrip1.ForeColor = Color.FromArgb(0, 0, 0);
        }
    }
}
