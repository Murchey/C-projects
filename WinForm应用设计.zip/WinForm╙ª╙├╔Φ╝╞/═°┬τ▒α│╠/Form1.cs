﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 网络编程
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Socket socketSend;
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //创建负责通信的Socket
                if (textServer.Text == "")
                {
                    MessageBox.Show("请先设置IP地址再开始连接");
                }
                socketSend = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPAddress ip = IPAddress.Parse(textServer.Text);
                IPEndPoint point = new IPEndPoint(ip, Convert.ToInt32(textPort.Text));
                //获得要远程连接的服务器IP和端口号
                socketSend.Connect(point);
                
                showMsg("连接成功");
                //开启一个新线程接受服务端发来的消息
                Thread th = new Thread(Receive);
                th.IsBackground = true;
                th.Start();
            }
            catch { }

        }
        void showMsg(string str)
        {
            textLog.AppendText(str+"\r\n");
        }
        /// <summary>
        /// 客户端给服务器发送消息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buSend_Click(object sender, EventArgs e)
        {
            try
            {
                string str = textMsg.Text.Trim();
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(str);
                socketSend.Send(buffer);
                textMsg.Text = "";
            }
            catch { }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;
        }
        /// <summary>
        /// 客户端接受服务器端发来的消息
        /// </summary>
        /// <param name="o"></param>
        void Receive(object o) 
        {
            try{
                while (true)
                {
                    byte[] buffer = new byte[1024 * 1024 * 2];
                    //实际接收到的有效字节数量
                    int r = socketSend.Receive(buffer);
                    if (r == 0)
                    {
                        break;
                    }
                    string str = Encoding.UTF8.GetString(buffer, 0, r);
                    //显示消息
                    showMsg(socketSend.RemoteEndPoint + ":" + str);
                    //客户端连接成功后，服务器应该接受客户端发来的消息
                }
            }
            catch{}
        }

        private void textServer_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("V1.1.0", "By Murchey");
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("如何设置IP\n需要设置服务端机器IP", "客户端");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timeToolStripMenuItem.Text = DateTime.Now.ToString();
        }
    
    }
}
