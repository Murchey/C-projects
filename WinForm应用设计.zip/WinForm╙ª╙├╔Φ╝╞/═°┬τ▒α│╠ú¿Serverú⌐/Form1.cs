﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 网络编程_Server_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        Socket socketWatch;
        //将远程连接到的IP和端口号存入集合中
        Dictionary<string,Socket> dicSocket=new Dictionary<string,Socket>();
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //当点击监听的时候 在服务器端创建一个负责监听IP和端口号的Socket
                if (textIP.Text == "")
                {
                    MessageBox.Show("请先设置IP地址再开始监听");
                }
                socketWatch = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPAddress ip = IPAddress.Any;
                //创建端口号对象
                IPEndPoint point = new IPEndPoint(ip, Convert.ToInt32(textPortListen.Text));
                //监听
                socketWatch.Bind(point);
                
                showMsg("正在监听");
                socketWatch.Listen(10);
                Thread th = new Thread(Listen);
                th.IsBackground = true;
                th.Start(socketWatch);
            }
            catch { }
        }
        Socket socketSend;//将通信Socket生命到外面方便其他方法调用
        /// <summary>
        /// 等待客户端的连接并且创建一个负责通信的Socket
        /// </summary>
        void Listen(object o)
        {
            Socket socketWatch = o as Socket;
            while (true)
            {
                try
                {
                    //等待客户端的连接并且创建一个负责通信的Socket
                    socketSend = socketWatch.Accept();
                    //将远程连接到的IP和端口号存入集合中
                    dicSocket.Add(socketSend.RemoteEndPoint.ToString(),socketSend);
                    //向下拉框中添加IP选项
                    cboUsers.Items.Add(socketSend.RemoteEndPoint.ToString());
                    showMsg(socketSend.RemoteEndPoint.ToString() + ":" + "连接成功");
                    //创建一个后台进程接收消息
                    Thread th = new Thread(Receive);
                    th.IsBackground = true;
                    th.Start(socketSend);
                }
                catch { }
            }
        }
        /// <summary>
        /// 客户端连接成功后，服务器应该接受客户端发来的消息
        /// </summary>
        void Receive(object o)
        {
            Socket socketSend = o as Socket;
            while (true)
            {
                try
                {
                    //客户端连接成功后，服务器应该接受客户端发来的消息
                    
                    byte[] buffer = new byte[1024 * 1024 * 2];
                    //实际接收到的有效字节数
                    int r = socketSend.Receive(buffer);
                    int n = buffer[0];//拿到字节数组第一位判断是什么类型的消息
                    if (n == 0)//文本消息
                    {
                        if (r == 0)
                        {
                            break;
                        }
                        string str = Encoding.UTF8.GetString(buffer, 1, r-1);
                        //显示消息
                        showMsg(socketSend.RemoteEndPoint + ":" + str);
                    }//if
                    else if (n == 1)
                    {
                        SaveFileDialog sfd = new SaveFileDialog();
                        sfd.Title = "对方发来文件：选择保存的文件位置";
                        sfd.Filter = "所有文件|*.*";
                        sfd.ShowDialog(this);
                        string path = sfd.FileName;
                        string ip = cboUsers.SelectedItem.ToString();
                        byte[] PathB = System.Text.Encoding.UTF8.GetBytes(path);
                        dicSocket[ip].Send(PathB);
                        using(FileStream fsWrite=new FileStream(path,FileMode.OpenOrCreate,FileAccess.Write))
                        {
                            fsWrite.Write(buffer,1,r-1);
                            MessageBox.Show("下载完成");
                        }
                    }//else if
                }
                catch { }
            }
        }
        /// <summary>
        /// 连接提示
        /// </summary>
        /// <param name="str"></param>
        void showMsg(string str) 
        {
            textLog.AppendText(str+"\r\n");
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls=false;
        }
        /// <summary>
        /// 服务器给客户端发送消息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buSend_Click(object sender, EventArgs e)
        {
            try
            {
                string str = textMsg.Text;
                byte[] buffer = System.Text.Encoding.UTF8.GetBytes(str);
                List<byte> list = new List<byte>();
                list.Add(0);
                list.AddRange(buffer);
                //将泛型集合转为数组
                byte[] newBuffer = list.ToArray();//0+text
                //字节数组首位为0代表发送文本消息
                //先获得用户在下拉框里选中的IP地址，再根据IP发送消息
                string ip = cboUsers.SelectedItem.ToString();
                dicSocket[ip].Send(newBuffer);
                //socketSend.Send(buffer);
                textMsg.Text = "";
            }
            catch { }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void 关于ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("V1.2.0","By Murchey");
        }

        private void 帮助ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("如何设置IP\n需要设置本机IP，查看IP的cmd命令是ipconfig", "TOCHAT");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timeToolStripMenuItem.Text = DateTime.Now.ToString();
        }
        /// <summary>
        /// 选择要发送的文件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buChoseFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Title="选择要发送的文件";
            ofd.Filter = "所有文件|*.*";
            ofd.ShowDialog();

            textPath.Text=ofd.FileName;

        }

        private void buSendFile_Click(object sender, EventArgs e)
        {
            try
            {
                //获得要发送文件的路径
                string path = textPath.Text;
                using (FileStream fsRead = new FileStream(path, FileMode.Open, FileAccess.Read))
                {
                    byte[] buffer = new byte[1024 * 1024 * 5];
                    List<byte> list = new List<byte>();
                    list.Add(1);
                    list.AddRange(buffer);
                    byte[] newBuffer = list.ToArray();
                    int r = fsRead.Read(buffer, 0, buffer.Length);
                    dicSocket[cboUsers.SelectedItem.ToString()].Send(newBuffer, 1, r + 1, SocketFlags.None);
                }//using
            }
            catch{}
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                //创建负责通信的Socket
                if (textConnect.Text == "")
                {
                    MessageBox.Show("请先设置IP地址再开始连接");
                }
                socketSend = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPAddress ip = IPAddress.Parse(textConnect.Text);
                IPEndPoint point = new IPEndPoint(ip, Convert.ToInt32(textPortConnect.Text));
                //获得要远程连接的服务器IP和端口号
                socketSend.Connect(point);

                showMsg("连接成功");
                //开启一个新线程接受服务端发来的消息
                Thread th = new Thread(Receive);
                th.IsBackground = true;
                th.Start();
            }
            catch { }
        }
    }
}
//通讯协议：0--文本  1--文件