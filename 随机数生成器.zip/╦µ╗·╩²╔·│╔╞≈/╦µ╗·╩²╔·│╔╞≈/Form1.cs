﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 随机数生成器
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static string Rnumber(int min, int max)
        {
            Random r = new Random();
            int rNum = r.Next(min, max);
            return rNum.ToString();//产生随机数的方法，并将返回的int型转为string
        }
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int min = Convert.ToInt32(txtMin.Text);//最小值
                int max = Convert.ToInt32(txtMax.Text);//最大值
                if (min < max)//正常情况，next方法左闭右开
                {
                    Range.Text = "[" + min + "," + max + ")";
                    txtrNum.Text = Rnumber(min, max);
                }
                else if (min == max)//最大最小值相等
                {
                    Range.Text = "当前范围只有一个数";
                    txtrNum.Text = min.ToString();
                }
                else //最小值大于最大值时为空集
                {
                    Range.Text = "∅";
                    txtrNum.Text = "Null";
                }
            }//try
            catch { }//异常捕获
        }
        
        public void Form1_Load(object sender, EventArgs e)
        {
         
        }
    }
}
