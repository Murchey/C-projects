﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 字符串的方法
{
    class Program
    {
        static void Main(string[] args)
        {
            //输入一个字符串，将返回其长度
            //Console.WriteLine("输入一个字符串，将返回其长度");
            //string str = Console.ReadLine();
            //Console.WriteLine("字符串的长度是{0},大写为{1},小写为{2}",str.Length,str.ToUpper(),str.ToLower());
            //Console.ReadKey();


            //让用户输入一个日期2022-11-24从中分析出年月日,返回2022年11月24日
            //string s = "2022-11-24";
            //char[] chs = {'-'};
            //string[] date = s.Split(chs,StringSplitOptions.RemoveEmptyEntries);
            //Console.WriteLine("{0}年{1}月{2}日",date[0],date[1],date[2]);
            //Console.ReadKey();


            //【字符串的替换】网站和谐关键字的原理
            //string s = "国家关键人物老赵";
            //if (s.Contains("老赵"))
            //{
            //    s = s.Replace("老赵","**");
            //}
            //Console.WriteLine(s);
            //Console.ReadKey();


            //练习：输出目录
            //目录文件内容如下：
            //钢铁是怎样炼成的     尼古拉·奥斯特洛夫斯基
            //流浪地球            刘慈欣
            //三体               刘慈欣
            //吞噬者             刘慈欣
            //string path = @"C:\Users\86183\Desktop\1.txt";
            //string[] contents = File.ReadAllLines(path);
            //console.readkey();
            //未完成


            //练习：反向输出用户输入的字符串
            //string str = "这是一句话";
            //#region 倒序输出
            //for (int i = str.Length-1; i >=0 ; i--)//倒序循环
            //{
            //    Console.Write(str[i]);
            //}//string[i]输出变量string中的第i个元素
            //#endregion
            //Console.ReadKey();

            //反转句子，不翻字母顺序
            string str = "hello c sharp";
            string[] strNew=str.Split(new char[] {' '},StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < strNew.Length/2; i++)
            {
                string temp = strNew[i];
                strNew[i] = strNew[strNew.Length - 1 - i];
                strNew[strNew.Length-1-i]=temp;
            }
            for (int i = 0; i < strNew.Length; i++)
            {
                Console.WriteLine(strNew[i]);
            }
            Console.ReadKey();


            
        }

    }
}
