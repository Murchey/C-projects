﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 解一元二次方程
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("请按照格式输入方程（ax^2+bx+c=0  a、b、c均为整数）");
                Console.WriteLine("a=");
                int a = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("b=");
                int b = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("c=");
                int c = Convert.ToInt32(Console.ReadLine());
                int derta = b * b - 4 * a * c;
                if (Derta(a, b, c))
                {
                    Console.WriteLine("该方程无解");
                    Console.ReadKey();
                }//if
                else
                {
                    double Uderta = Unsquare(derta);
                    double x1 = (-b + Uderta) / 2 * a;
                    double x2 = (-b - Uderta) / 2 * a;
                    Console.WriteLine("X1={0}", x1);
                    Console.WriteLine("X2={0}", x2);
                    Console.ReadKey();
                }//else
            }//try
            catch 
            {
                Console.WriteLine("输入类型有误，不能为空或非整数");
                Console.WriteLine("请重新开启程序");
                Console.ReadKey();
            }//catch


        }
    public static bool Derta (int a ,int b ,int c)
    {       
        bool derta = b * b - 4 * a * c<0;
        return (derta);
    }//判别式
    public static double Unsquare(int derta)
    {
        int xderta = derta*derta;
        double result = 0;
        double xresult = 0;
        bool c;
        do
        {
            result = result + 0.001;
            xresult = result * result;
            c = (xresult < xderta);

        }
        while (c);
        if (result == 1)
        {
            return (result);
        }
        else { 
        result = result - 0.001;
        return (result);
        }
    }//开方
    //x1=(-b+根b^2-4*a*c)/2*a
    //x2=(-b-根b^2-4*a*c)/2*a
    
    }
}
