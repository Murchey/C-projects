﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 类的练习
{
    class Program
    {
        static void Main(string[] args)
        {


            Console.WriteLine("请输入行程（Km）");
            double d = Convert.ToDouble(Console.ReadLine());
            ticket t = new ticket(d);
            t.ShowTicketPrice();
            Console.ReadKey();


        }
    }
}
