﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 类的练习
{
    class ticket
    {
        private double _distance;
        public double Distance 
        {
            get { return _distance;}
        }//Distance
        public ticket(double distance)
        {
            if (distance < 0)
            {
                distance = 0;
            }//if
            this._distance = distance;
        }//public ticket


        private double _price;
        public double Price 
        {
            get {
                if (_distance > 0 && _distance <= 101)
                { return _distance * 1.0; }
                else if (_distance > 101 && _distance <= 200)
                { return _distance * 9.5; }
                else if (_distance > 201 && _distance <= 300)
                { return _distance * 9.0; }
                else 
                { return _distance * 8.0; }
                return _price; }//get
        }//double Price
        public void ShowTicketPrice() 
        {
            Console.WriteLine("{0}公里车程需要{1}元",Distance,Price);
        }//ShowTicketPrice
        

        //类中的运算变量全部是用字段，输出时全部使用属性
    }
}
