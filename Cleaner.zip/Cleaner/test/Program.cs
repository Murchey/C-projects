﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] orders={"del /Q",".\\1.txt"," "};
            string final=orders[0]+orders[2]+orders[1];
            File.WriteAllText("0.bat",final , Encoding.Default);
            Process.Start("0.bat");
        }
    }
}
