﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Cleaner
{
    class Program
    {


        static void Main(string[] args)
        {
            //思路如下：
            //1.在当前文件夹创建targets.ini收集目标路径-OK
            //2.创建xml文档更改设置-OK
            //3.创建bat/cmd脚本执行删除命令
            //del /Q静默删除
            //报错处理核心;
            //1.元素下标超出限制
            //2.写入脚本文件时要Encoding.Default
            //需要补充：生成脚本文件时要判断是文件还是文件夹，文件用del /Q,文件夹用rmdir /Q
            try
            {
                #region 对XML文件的操作
                XmlDocument doc = new XmlDocument();
                if (File.Exists("Settings.xml"))
                {
                    #region 加载XML文件
                    doc.Load("Settings.xml");
                    XmlElement Settings = doc.DocumentElement;
                    //加载根节点

                    //XmlNodeList xnl = Settings.ChildNodes;
                    //获得所有节点的集合
                    XmlNode OPATF_XML = Settings.SelectSingleNode("OutPutATxtFile");
                    string OPATF_STR = OPATF_XML.InnerText.ToString();
                    //读取OutPutATxtFile节点的内容

                    XmlNode TEDS_XML = Settings.SelectSingleNode("TheExtentionsOfScript");
                    string TEDS_STR = TEDS_XML.InnerText.ToString();
                    //读取TheExtentionsOfScript节点的内容

                    XmlNode TFN_XML = Settings.SelectSingleNode("TargetsFileName");
                    string TFN_STR = TFN_XML.InnerText.ToString();
                    //读取TargetsFileName节点的内容

                    XmlNode TFE_XML = Settings.SelectSingleNode("TargetsFileExtention");
                    string TFE_STR = TFE_XML.InnerText.ToString();
                    //读取TargetsFileExtention节点的内容

                    XmlNode AON_XML = Settings.SelectSingleNode("AskOrNot");
                    string AON_STR = AON_XML.InnerText.ToString();
                    //读取AskOrNot节点的内容
                    #endregion
                    ToTargetsINI(TFN_STR, TFE_STR, OPATF_STR, TEDS_STR, AON_STR);
                    Console.ReadKey();
                }
                else
                { //Setting.xml文件不存在时候创建
                    #region 创建XML配置文件
                    //XmlDocument doc = new XmlDocument();
                    XmlDeclaration dec = doc.CreateXmlDeclaration("1.0", "UTF-8", null);
                    doc.AppendChild(dec);//xml文件头

                    XmlElement Settings = doc.CreateElement("Settings");
                    doc.AppendChild(Settings);
                    //根节点Settings


                    XmlElement OutPutATxtFile = doc.CreateElement("OutPutATxtFile");
                    Settings.AppendChild(OutPutATxtFile);
                    OutPutATxtFile.InnerText = "false";
                    OutPutATxtFile.SetAttribute("description", "用来保存是否输出一个txt文件显示删除的文件");
                    //子节点OutPutATxtFile,用来保存是否输出一个txt文件显示删除的文件


                    XmlElement TheExtentionsOfScript = doc.CreateElement("TheExtentionsOfScript");
                    Settings.AppendChild(TheExtentionsOfScript);
                    TheExtentionsOfScript.InnerText = "cmd";
                    TheExtentionsOfScript.SetAttribute("description", "用来保存脚本的扩展名");
                    //子节点TheExtentionsOfScript，用来保存脚本的扩展名


                    XmlElement TargetsFileName = doc.CreateElement("TargetsFileName");
                    Settings.AppendChild(TargetsFileName);
                    TargetsFileName.InnerText = "Targets";
                    TargetsFileName.SetAttribute("description", "用来保存Targets.ini文件的名称");
                    //子节点TargetsFileName，用来保存Targets.ini文件的名称


                    XmlElement TargetsFileExtention = doc.CreateElement("TargetsFileExtention");
                    Settings.AppendChild(TargetsFileExtention);
                    TargetsFileExtention.InnerText = "ini";
                    TargetsFileExtention.SetAttribute("description", "用来保存Targets.ini文件的后缀");
                    //子节点TargetsFileExtention，用来保存Targets.ini文件的后缀

                    XmlElement AskOrNot = doc.CreateElement("AskOrNot");
                    Settings.AppendChild(AskOrNot);
                    AskOrNot.InnerText = "true";
                    AskOrNot.SetAttribute("description", "操作之前是否询问");
                    //子节点AskOrNot，用来保存操作之前是否询问

                    doc.Save("Settings.xml");
                    #endregion
                    File.Open("Targets.ini", FileMode.OpenOrCreate);
                    Console.WriteLine("已创建配置文件，请重启软件");
                    Console.ReadKey();
                }
                #endregion
            }
            catch { }
            

        }
        public static void ToTargetsINI(string TFN_STR, string TFE_STR, string OPATF_STR, string TEDS_STR, string AON_STR)
        {
            try
            {
                string TargetsName = TFN_STR + "." + TFE_STR;
                if (File.Exists(TargetsName))
                {
                    Console.WriteLine("已经存在文件{0}，编辑请使用UTF-8", TargetsName);
                    //文件存在时直接删除
                    #region 询问
                    if (AON_STR == "true")//不询问是否删除时候直接删除
                    {
                        Console.WriteLine("是否删除目标？（Y/N）");
                        string answer = Console.ReadLine();
                        if (answer == "Y" || answer == "y")
                        {
                            DeleteFiles(TargetsName, TEDS_STR, OPATF_STR);
                        }
                        else
                        {
                            Console.WriteLine("操作取消！");
                            Console.ReadLine();
                        }
                    #endregion
                    }
                    else//文件不存在时先创建再删除
                    {
                        File.Open(TargetsName,FileMode.OpenOrCreate);
                        #region 询问
                        if (AON_STR == "true")//不询问是否删除时候直接删除
                        {
                            Console.WriteLine("是否删除目标？（Y/N）");
                            string answer = Console.ReadLine();
                            if (answer == "Y" || answer == "y")
                            {
                                DeleteFiles(TargetsName, TEDS_STR, OPATF_STR);
                                Console.ReadKey();
                            }
                            else
                            {
                                Console.WriteLine("操作取消！");
                                Console.ReadLine();
                            }
                        }
                        else
                        {
                            DeleteFiles(TargetsName, TEDS_STR, OPATF_STR);
                            Console.ReadKey();
                        }
                        #endregion
                    }
                }
            }
            catch {
                Console.WriteLine("ERROR!");
                Console.ReadKey();
            }
        }
        public static void DeleteFiles(string TargetsName,string TEDS_STR,string OPATF_STR)
        {
            try{
                if (OPATF_STR == "false")
                {
                    #region 删除操作核心
                    string[] allTargets = File.ReadAllLines(TargetsName,Encoding.UTF8);
                    string[] orders = new string[allTargets.Length + 3];
                    for (int i = 0; i < allTargets.Length; i++)
                    {
                        if (Directory.Exists(allTargets[i]))
                        {
                            orders[i] = "rmdir /Q" + " " + allTargets[i];
                        }
                        else
                        {
                            orders[i] = "del /Q" + " " + allTargets[i];
                        }
                    }

                    orders[orders.Length - 3] = "del /Q " + TargetsName;//倒数第三个元素
                    orders[orders.Length - 2] = "del /Q Settings.xml";//倒数第二个
                    orders[orders.Length - 1] = "del /Q " + "delete." + TEDS_STR; //倒数第一个，最后一个元素

                    string ScriptName = "delete." + TEDS_STR;//脚本名称
                    File.WriteAllLines(ScriptName, orders, Encoding.Default);
                    Process.Start(ScriptName);
                    Console.WriteLine("操作完成");
                    Console.ReadKey();
                    #endregion
                }
                else
                {
                    #region 删除操作核心+保存删除的文件路径
                    string[] allTargets = File.ReadAllLines(TargetsName, Encoding.UTF8);
                    File.WriteAllLines("删除的文件和路径.txt", allTargets, Encoding.UTF8);//输出文件
                    string[] orders = new string[allTargets.Length + 3];
                    for (int i = 0; i < allTargets.Length; i++)
                    {
                        if (Directory.Exists(allTargets[i]))
                        {
                            orders[i] = "rmdir /Q" + " " + allTargets[i];
                        }
                        else
                        {
                            orders[i] = "del /Q" + " " + allTargets[i];
                        }
                    }

                    orders[orders.Length - 3] = "del /Q " + TargetsName;//倒数第三个元素
                    orders[orders.Length - 2] = "del /Q Settings.xml";//倒数第二个
                    orders[orders.Length - 1] = "del /Q " + "delete." + TEDS_STR; //倒数第一个，最后一个元素

                    string ScriptName = "delete." + TEDS_STR;//脚本名称
                    File.WriteAllLines(ScriptName, orders, Encoding.Default);
                    Process.Start(ScriptName);
                    Console.WriteLine("操作完成");
                    Console.ReadKey();
                    #endregion
                }
            }
            catch
            {
                Console.WriteLine("Error!");
                Console.ReadKey();
            }
        }
    }
}
