﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 随机密码生成器
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //txtPwd.Text = allBytes.Length.ToString();
            
        }

public char[] allBytes = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
                                'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z',
                                ',','.','/','-','+','*','=','?','!',':',';','<','>','[',']','{','}','(',')','@','#','$','%','^','&','|','\\'};
        //字符集，79个
        private void buStart_Click(object sender, EventArgs e)
        {
            try
            {
                
                txtPwd.Text = "";//初始化文本框
                Random r = new Random();
                int pwdLength = Convert.ToInt32(txtLength.Text);//The length of password
                int rNum;

                if (pwdLength >= 200)
                {
                    MessageBox.Show("超过200个字符会导致电脑卡顿，是否继续？\n否请关闭程序");
                }
                for (int i = 0; i < pwdLength + 1; i++)
                {
                    rNum = r.Next(0, 79);
                    txtPwd.Text += allBytes[rNum].ToString();
                }
            }
            catch { }
        }
    }
}
