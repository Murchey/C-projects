﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MD5加密
{
    class Program
    {
        static void Main(string[] args)
        {
            //明文：123
            //密文：202cb962ac59075b964b07152d234b70
            string str = "123";
            string MD5value=GetMD5(str);
            Console.WriteLine(MD5value);
            Console.ReadKey();
            //结果：202cb962ac59075b964b07152d234b70
        }

        public static string GetMD5(string str)
        {
            MD5 md5 = MD5.Create();
            byte[] buffer = Encoding.Default.GetBytes(str);
            byte[] MD5Buffer = md5.ComputeHash(buffer);
            string strNew = "";
            for (int i = 0; i <MD5Buffer.Length ; i++)
            {
                strNew += MD5Buffer[i].ToString("x2");
            }
            return strNew;
        }


    }
}
